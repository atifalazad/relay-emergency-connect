import { build } from 'esbuild';
import { mkdir, copyFile, writeFile } from 'node:fs/promises';
await mkdir('dist', { recursive: true });
const result = await build({ entryPoints: ['src/app.jsx'], bundle: true, minify: true, legalComments: 'inline', format: 'esm', target: ['es2022'], outfile: 'dist/app.js', write: false, jsx: 'automatic', define: { 'process.env.NODE_ENV': '"production"' } });
if (process.argv.includes('--write-bridge')) {
  const response = await fetch('http://127.0.0.1:4174/bundle', { method: 'POST', body: result.outputFiles[0].contents });
  if (!response.ok) throw new Error('Local output bridge failed');
  console.log('Najda bundle built and saved.');
  process.exit(0);
}
await writeFile('dist/app.js', result.outputFiles[0].contents);
await copyFile('src/style.css', 'dist/style.css');
await copyFile('src/index.html', 'dist/index.html');
await copyFile('src/campus-data.json', 'dist/campus-data.json');
await copyFile('public/relay-waves.webp', 'dist/relay-waves.webp');
for (const name of ['favicon.svg','favicon.ico','apple-touch-icon.png']) await copyFile('public/'+name,'dist/'+name);
for(const name of ['school-doodles.webp','school-doodles-mono.webp','manifest.webmanifest','sw.js','app-icon-192.png','app-icon-512.png','manrope.woff2'])await copyFile('public/'+name,'dist/'+name);
for(const name of ['najda-wordmark.svg','najda-wordmark.png'])await copyFile('public/'+name,'dist/'+name);
console.log('Najda built: dist/index.html');
