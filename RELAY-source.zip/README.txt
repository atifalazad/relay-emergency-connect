RELAY - Emergency Connect
Designed by Atif Al Azad
XI-D | 10673 | Rose House

PUBLIC PROTOTYPE
https://atif10ala.github.io/relay-emergency-connect/
Opens in a desktop or phone browser. No installation or sign-in is needed.

SUBMISSION FILES
RELAY-interface.pdf: complete interface booklet, including desktop, teacher and phone screens.
RELAY-screens.zip: 20 PNG screen exports.
RELAY-statement.txt: the 117 word design explanation.
RELAY-prototype.html: self-contained interactive browser prototype.
RELAY-source.zip: editable source project and locally bundled preview files.

EDITABLE FIGMA DESIGN
https://www.figma.com/design/XOlQnT3KD1hKTA9R7FfZZl

FIGMA PROTOTYPE
Desktop:
https://www.figma.com/proto/XOlQnT3KD1hKTA9R7FfZZl?node-id=6-2&starting-point-node-id=6%3A2
Phone:
https://www.figma.com/proto/XOlQnT3KD1hKTA9R7FfZZl?node-id=6-950&starting-point-node-id=6%3A950

Set the intended viewing access using Figma's Share control before forwarding the link to the House Warden. The live local preview is http://127.0.0.1:4173/ while this computer's preview server is running.

TRY THE COMPLETE FLOW
Choose a help type and a campus location, review, and send.
Use the Student / Teacher switch to open the request as Mrs. Aditi and accept responsibility.
Return to Student, read the acknowledgement, use text, and confirm adult handover.
Demo controls includes connection loss, unanswered requests and reset.

3D AND THEMES
The help symbol floats gently on its own. Pause motion stops it. The campus map can still be dragged or rotated with buttons.
Help types have different colours and symbols. Light is the default, with an optional dark theme.
Soft blue wave lines sit behind the interface. Help selections and page changes use short transitions. Reduced motion pauses the symbol and disables those transitions. Text and controls are enlarged for desktop and phone.

IMPLEMENTATION NOTES
Requests, teacher availability, pings and chat responses are simulated within the browser. No alert server or GPS tracking is connected. Call teacher opens Mrs. Aditi's supplied number in the device dialler only when the number is tapped. The nearest-contact calculation uses manually selected campus zones and the example directory assignment, rather than live teacher locations.
The campus is an approximate exterior model using public imagery and participant corrections. No interiors are reconstructed.
The Figma file contains editable text, component instances, colours and official vector icons. Its linked static states cover all help types; the browser version has the live 3D, editable input fields and simulated state changes.

ASSET CREDITS
Manrope: Open Font Licence.
Tabler icons: MIT licence, https://github.com/tabler/tabler-icons.
RELAY layout, code and model are project-specific.

OFFLINE
The self-contained HTML can display without internet. Real notifications would require a connected service; the current request flow is a simulation. Calls require mobile voice coverage.

SCHOOL LOGO
Official DPS-Modern Indian School crest from https://website.dpsmisdoha.com/wp-content/themes/dps/images/logo.png. The crest appears in the desktop school panel and beside the phone wordmark.

The wave texture was generated for this project from the participant’s visual reference. The RELAY favicon uses the existing wordmark style.
