import io,json,urllib.request,zipfile
from pathlib import Path
from PIL import Image
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from pypdf import PdfReader
ROOT=Path(__file__).resolve().parent
OUT=ROOT.parent.parent/'outputs'/'mobile-submission'
REG,BOLD='Helvetica','Helvetica-Bold'
try:
 from fontTools.ttLib import TTFont as FTFont
 from fontTools.varLib.instancer import instantiateVariableFont
 for name,weight in [('Manrope',400),('ManropeBold',800)]:
  f=FTFont(ROOT/'dist'/'manrope.woff2');f.flavor=None
  if 'fvar' in f:f=instantiateVariableFont(f,{'wght':weight},inplace=True)
  b=io.BytesIO();f.save(b);b.seek(0);pdfmetrics.registerFont(TTFont(name,b))
 REG,BOLD='Manrope','ManropeBold'
except Exception as e:print('Font fallback',type(e).__name__)
INK=HexColor('#111a2b');MUTED=HexColor('#53637d');BLUE=HexColor('#2859d6');PAPER=HexColor('#f3f6fc');LINE=HexColor('#d9e2ef')
W,H=842,595
URL='https://atif10ala.github.io/relay-emergency-connect/'
statement=(OUT/'RELAY-statement.txt').read_text(encoding='utf-8').strip()
assert 100<=len(statement.split())<=150
b=io.BytesIO();c=canvas.Canvas(b,pagesize=(W,H),pageCompression=1)
c.setTitle('RELAY | Emergency Connect | Mobile interface')
c.setAuthor('Atif Al Azad | XI-D | 10673 | Rose House')
def text(s,x,y,size=12,bold=False,color=INK):
 c.setFillColor(color);c.setFont(BOLD if bold else REG,size);c.drawString(x,y,s)
def para(s,x,y,width,size=12,leading=18,color=MUTED):
 line=''
 for word in s.split():
  test=(line+' '+word).strip()
  if line and pdfmetrics.stringWidth(test,REG,size)>width:
   text(line,x,y,size,color=color);y-=leading;line=word
  else:line=test
 if line:text(line,x,y,size,color=color);y-=leading
 return y
def bg(page,kicker,title):
 c.setFillColor(PAPER);c.rect(0,0,W,H,fill=1,stroke=0)
 text(kicker.upper(),28,566,9,True,BLUE);text(title,28,534,25,True)
 text('RELAY  /  '+str(page).zfill(2),746,566,9,color=MUTED)
def jpeg(path):
 im=Image.open(path).convert('RGB');s=io.BytesIO();im.save(s,'JPEG',quality=86,optimize=True,subsampling=0);s.seek(0);return ImageReader(s)
def phone(stem,x,y=50,w=200):
 bezel=6;inner=w-2*bezel;image_h=inner*853/393;status=28;bottom=14
 h=image_h+status+bottom+2*bezel
 c.setFillColor(HexColor('#d8dfeb'));c.roundRect(x+3,y-3,w,h,30,fill=1,stroke=0)
 c.setFillColor(HexColor('#171b22'));c.roundRect(x,y,w,h,30,fill=1,stroke=0)
 c.setStrokeColor(HexColor('#59616c'));c.setLineWidth(.7);c.roundRect(x+1.5,y+1.5,w-3,h-3,28.5,fill=0,stroke=1)
 c.setFillColor(HexColor('#ffffff'));c.roundRect(x+bezel,y+bezel,inner,h-2*bezel,25,fill=1,stroke=0)
 c.saveState();p=c.beginPath();p.roundRect(x+bezel,y+bezel,inner,h-2*bezel,25);c.clipPath(p,stroke=0,fill=0)
 c.drawImage(jpeg(OUT/'views'/(stem+'.png')),x+bezel,y+bezel+bottom,inner,image_h)
 c.restoreState()
 sy=y+bezel+bottom+image_h
 text('9:41',x+18,sy+9,8,True)
 c.setFillColor(HexColor('#060709'));c.roundRect(x+w/2-33,sy+6,66,17,9,fill=1,stroke=0)
 for i in range(3):c.rect(x+w-44+i*3.2,sy+9,2,3+i*2,fill=1,stroke=0)
 c.setStrokeColor(INK);c.setLineWidth(.7);c.roundRect(x+w-28,sy+10,15,7,2,fill=0,stroke=1)
 c.setFillColor(INK);c.roundRect(x+w-26,sy+11.5,11,4,1,fill=1,stroke=0);c.rect(x+w-12,sy+12,1.5,3,fill=1,stroke=0)
 c.roundRect(x+w/2-31,y+10,62,3,1.5,fill=1,stroke=0)
 c.setFillColor(HexColor('#353b45'));c.roundRect(x-1.5,y+h-115,2,33,1,fill=1,stroke=0);c.roundRect(x+w-.5,y+h-146,2,48,1,fill=1,stroke=0)
 return h
def caption(num,title,body,x,y=465,width=148):
 text(num,x,y,10,True,BLUE);yy=para(title,x,y-31,width,17,23,INK)-8
 return para(body,x,yy,width,12,18)
def bottom(page):
 c.setStrokeColor(LINE);c.line(28,29,814,29);text('DPS MODERN INDIAN SCHOOL  /  EMERGENCY CONNECT',28,14,8,color=MUTED)
def pair(page,kicker,title,left,right):
 bg(page,kicker,title)
 phone(left[0],28);caption(left[1],left[2],left[3],246)
 phone(right[0],430);caption(right[1],right[2],right[3],648)
 
 if page==6:
  text('Demonstration: requests, pings and office escalation are simulated. Live delivery and the 30-second policy need school approval.',28,14,8,color=MUTED)
 else:bottom(page)
 c.showPage()
# 1: brief, statement and opening screen
bg(1,'UI/UX design challenge','')
text('relay',36,493,62,True);c.setFillColor(BLUE);c.circle(199,506,4,fill=1,stroke=0)
text('Help starts here.',38,439,29,True)
para('A school assistance app built around the first few taps.',39,409,425,15,22)
text('DESIGN STATEMENT',39,350,9,True,BLUE)
end=para(statement,39,326,425,12,19,INK)
text(str(len(statement.split()))+' words',39,end-4,8,color=MUTED)
text('Atif Al Azad',39,79,16,True);text('XI-D | 10673 | Rose House',39,57,11,color=MUTED)
phone('01-home',579,50,200)
text('OPEN THE INTERACTIVE APP',39,22,9,True,BLUE)
c.linkURL(URL,(38,12,435,40),relative=0,thickness=0)
text('atif10ala.github.io/relay-emergency-connect/',221,22,8,color=BLUE)
c.showPage()
pair(2,'Student / details','A useful location, with fewer decisions.',
 ('02-location','01 / LOCATION','A floor is enough.','Ground, Floor 1 and Floor 2 have large tap targets. A block, room or map is optional. “Not sure” keeps help available.'),
 ('03-review','02 / REVIEW','Check, then send.','The request shows the selected help type and location. Back and Edit preserve choices. The Send button stays within reach.'))
pair(3,'Teacher / response','The request reaches a shared inbox.',
 ('07-teacher-inbox','03 / INBOX','Visible immediately.','A request appears in the shared queue before any individual accepts it. In-app pings are labelled; no SMS or WhatsApp is implied.'),
 ('08-teacher-request','04 / FOLLOW-UP','A person takes responsibility.','Mrs. Aditi can acknowledge the request and reply. Her contact comes from a fixed directory. No live proximity or “nearest teacher” claim is made.'))
pair(4,'Student / connection','Know what has happened. Keep talking.',
 ('04-status','05 / STATUS','Acknowledged is a clear state.','The timeline separates delivery, a teacher response and adult handover. Calling and messaging remain available while waiting.'),
 ('05-chat','06 / CHAT','Help without speaking.','Quick replies and text support students who cannot speak. Messages can go to the school inbox before a teacher acknowledges.'))
bg(5,'Student / handover','Close the loop when an adult is there.')
phone('06-handover',42)
text('07 / HANDOVER',294,473,10,True,BLUE)
text('A reply does not mean arrival.',294,438,23,True)
para('The student confirms that a responsible adult is physically present before closing the request. The selected location is then cleared.',295,404,480,14,22)
text('Built for a school day.',294,309,21,True)
choices=[
 ('Speed','Floor and help type on the opening screen. No account setup in the emergency flow.'),
 ('Accessibility','Large touch controls, readable text, keyboard focus, text-only support and reduced-motion styling.'),
 ('Identity','The school crest, notebook doodles and flowing light along the waves. Decorative motion can be paused.'),
 ('Phone access','Open the link in a browser or add it to the home screen. The desktop layout remains available.')]
yy=274
for heading,body in choices:
 text(heading,295,yy,12,True,BLUE);yy=para(body,389,yy,385,12,18)-17
bottom(5);c.showPage()
pair(6,'Reliability / edge cases','When nobody replies, or the connection fails.',
 ('09-escalation','08 / ESCALATION','Follow-up has a deadline.','After 30 seconds without acknowledgement, the prototype adds an office escalation. Students can also escalate immediately and call directly.'),
 ('10-offline','09 / CONNECTION LOSS','Unsent stays unsent.','Details remain available for retry. A failed request or escalation is never shown as delivered. The interface can reopen offline after a first visit.'))
c.save()
pdf=b.getvalue();reader=PdfReader(io.BytesIO(pdf));assert len(reader.pages)==6
for page in reader.pages:assert len(page.extract_text())>100
assert len(pdf)<5_000_000,len(pdf)
def post(name,data):urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:4176/'+name,data=data,method='POST')).read()
post('RELAY-submission.pdf',pdf)
z=io.BytesIO()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as out:
 for path in sorted((OUT/'screens').glob('*.png')):out.writestr(path.name,path.read_bytes())
 out.writestr('README.txt','Phone screenshots of ten core screens and states. The iPhone frame in the PDF is for presentation. Requests, pings and escalation are browser simulations; no live school notification service is connected. The 30-second threshold is an illustrative design rule, subject to school approval.')
post('RELAY-screen-exports.zip',z.getvalue())
print(json.dumps({'pages':len(reader.pages),'pdf_bytes':len(pdf),'statement_words':len(statement.split()),'screens':10}))
