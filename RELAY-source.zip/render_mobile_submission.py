import json
import subprocess
import sys
import urllib.request
from pathlib import Path
from pypdf import PdfReader

root = Path(__file__).resolve().parent
pdf = root.parent.parent / 'outputs' / 'mobile-submission' / 'RELAY-submission.pdf'
poppler = Path('C:/Users/Anas Al Azad/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin/pdftoppm.exe')
reader = PdfReader(pdf)
page_numbers = [int(value) for value in sys.argv[1:]] or list(range(1, len(reader.pages) + 1))
for index in page_numbers:
    result = subprocess.run([str(poppler), '-f', str(index), '-l', str(index), '-singlefile', '-scale-to', '1400', '-png', str(pdf)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
    assert result.stdout.startswith(b'\x89PNG\r\n\x1a\n'), result.stderr[:1000]
    request = urllib.request.Request(f'http://127.0.0.1:4176/page-{index:02d}.png', data=result.stdout, method='POST')
    urllib.request.urlopen(request).read()
print(json.dumps({'rendered_pages': page_numbers, 'dimensions': [list(page.mediabox) for page in reader.pages[:3]], 'statement_in_pdf': 'RELAY is a school assistance app' in reader.pages[0].extract_text()}))
