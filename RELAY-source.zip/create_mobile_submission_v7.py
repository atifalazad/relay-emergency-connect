import io,json,urllib.request,zipfile
from pathlib import Path
from PIL import Image
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from pypdf import PdfReader
ROOT=Path(__file__).resolve().parent
OUT=ROOT.parent.parent/'outputs'/'mobile-submission'
REG,BOLD='Helvetica','Helvetica-Bold'
try:
 pdfmetrics.registerFont(TTFont('RelaySans','C:/Windows/Fonts/segoeui.ttf'))
 pdfmetrics.registerFont(TTFont('RelayBold','C:/Windows/Fonts/segoeuib.ttf'))
 REG,BOLD='RelaySans','RelayBold'
except Exception:pass
INK=HexColor('#152038');MUTED=HexColor('#56657e');BLUE=HexColor('#2859d6');PAPER=HexColor('#f7f9fc');LINE=HexColor('#dce3ed')
URL='https://atif10ala.github.io/relay-emergency-connect/'
W,H=842,595
statement=(OUT/'RELAY-statement.txt').read_text(encoding='utf-8').strip()
assert 100<=len(statement.split())<=150
def text(c,s,x,y,size=12,bold=False,color=INK):
 c.setFillColor(color);c.setFont(BOLD if bold else REG,size);c.drawString(x,y,s)
def para(c,s,x,y,width,size=13,leading=20,color=MUTED):
 for raw in s.split('\n'):
  line=''
  for word in raw.split():
   test=(line+' '+word).strip()
   if line and pdfmetrics.stringWidth(test,REG,size)>width:
    text(c,line,x,y,size,color=color);y-=leading;line=word
   else:line=test
  if line:text(c,line,x,y,size,color=color);y-=leading
  y-=5
 return y
def jpeg(path):
 im=Image.open(path).convert('RGB');out=io.BytesIO();im.save(out,'JPEG',quality=86,optimize=True,subsampling=0);out.seek(0);return ImageReader(out)
def phone(c,stem,x,y=60,w=208):
 bezel=6;inner=w-12;image_h=inner*853/393;top=26;bottom=12
 h=image_h+top+bottom+12
 c.setFillColor(HexColor('#e1e6ef'));c.roundRect(x+3,y-3,w,h,29,fill=1,stroke=0)
 c.setFillColor(HexColor('#181b22'));c.roundRect(x,y,w,h,29,fill=1,stroke=0)
 c.setStrokeColor(HexColor('#68727e'));c.setLineWidth(.6);c.roundRect(x+1.5,y+1.5,w-3,h-3,27.5,fill=0,stroke=1)
 c.setFillColor(HexColor('#ffffff'));c.roundRect(x+bezel,y+bezel,inner,h-12,24,fill=1,stroke=0)
 c.saveState();p=c.beginPath();p.roundRect(x+bezel,y+bezel,inner,h-12,24);c.clipPath(p,stroke=0,fill=0)
 c.drawImage(jpeg(OUT/'views'/(stem+'.png')),x+bezel,y+bezel+bottom,inner,image_h)
 c.restoreState()
 sy=y+bezel+bottom+image_h
 c.setFillColor(HexColor('#050608'));c.roundRect(x+w/2-33,sy+6,66,15,8,fill=1,stroke=0)
 c.roundRect(x+w/2-31,y+9,62,3,2,fill=1,stroke=0)
def header(c,page):
 c.setFillColor(PAPER);c.rect(0,0,W,H,fill=1,stroke=0)
 text(c,'relay',39,561,19,True);c.setFillColor(BLUE);c.circle(86,565,2,fill=1,stroke=0)
 text(c,'EMERGENCY CONNECT',105,565,8.5,True,BLUE)
 text(c,'DPS MODERN INDIAN SCHOOL',105,553,7.5,color=MUTED)
 c.setStrokeColor(LINE);c.line(39,542,291,542)
 text(c,'atif10ala.github.io/relay-emergency-connect/',39,21,8.8,color=BLUE)
 c.linkURL(URL,(37,13,295,35),relative=0,thickness=0)
 text(c,str(page).zfill(2)+' / 05',770,21,9,color=MUTED)
def feature(c,label,body,y):
 text(c,label,40,y,12,True,BLUE)
 return para(c,body,40,y-22,235,12,18)-16
pages=[
 ('STUDENT / START','Help starts\nhere.','A floor and a help type get the request started. Add a block only if you know it.',
  [('Location first','Large floor choices on the opening screen.'),('Your school, your words','Choose A, B or C Block. “Not sure” stays available.')],
  ('01-home','01 / HOME'),('02-location','02 / LOCATION')),
 ('STUDENT / REQUEST','A clear\nnext step.','Check the help type and location, then follow the response.',
  [('Easy to change','Back and Edit preserve the choices already made.'),('Clear status','Delivery, acknowledgement and arrival are separate states.')],
  ('03-review','03 / REVIEW'),('04-status','04 / STATUS')),
 ('STUDENT / CONNECTION','Keep the\nconnection.','Use text when speaking is difficult. Close the request once a responsible adult is there.',
  [('A quiet way to ask','Quick replies and messages work before acknowledgement.'),('Confirmed handover','The student closes the request after meeting an adult.')],
  ('05-chat','05 / CHAT'),('06-handover','06 / HANDOVER')),
 ('TEACHER / RESPONSE','The other\nside of help.','The shared inbox receives the request immediately. Mrs. Aditi can acknowledge and reply.',
  [('Shared responsibility','An individual accepting is not a condition of delivery.'),('An explicit channel','A ping goes to the in-app inbox. The contact is from the school directory.')],
  ('07-teacher-inbox','07 / INBOX'),('08-teacher-request','08 / FOLLOW-UP')),
 ('RELIABILITY / EDGE CASES','When help is\nstill pending.','An unanswered request triggers follow-up. A connection failure stays visible.',
  [('30-second escalation','The prototype adds an office escalation if nobody acknowledges. Escalate now is also available.'),('Unsent stays unsent','Keep the details, retry or use the direct-call options.')],
  ('09-escalation','09 / ESCALATION'),('10-offline','10 / CONNECTION LOSS'))
]
buf=io.BytesIO();c=canvas.Canvas(buf,pagesize=(W,H),pageCompression=1)
c.setTitle('RELAY | Emergency Connect | Mobile interface')
c.setAuthor('Atif Al Azad | XI-D | 10673 | Rose House')
for page,(kicker,title,body,features,left,right) in enumerate(pages,1):
 header(c,page);text(c,kicker,40,513,9,True,BLUE)
 yy=477
 for line in title.split('\n'):text(c,line,39,yy,34,True);yy-=40
 yy=para(c,body,40,yy-9,235,14,22)-17
 for label,detail in features:yy=feature(c,label,detail,yy)
 if page==1:
  text(c,'Atif Al Azad',40,94,14,True);text(c,'XI-D | 10673 | Rose House',40,74,10,color=MUTED)
 if page==5:
  para(c,'Requests, pings and office escalation are simulated. Live delivery and the timing policy require school approval.',40,102,235,9.5,14)
 for entry,x in [(left,330),(right,575)]:
  text(c,entry[1],x+2,550,9,True,BLUE);phone(c,entry[0],x)
 c.showPage()
c.save();interface=buf.getvalue();assert len(PdfReader(io.BytesIO(interface)).pages)==5
# Separate, readable statement file.
st=io.BytesIO();c=canvas.Canvas(st,pagesize=(595,842),pageCompression=1)
c.setTitle('RELAY | Design statement');c.setAuthor('Atif Al Azad | XI-D | 10673 | Rose House')
c.setFillColor(PAPER);c.rect(0,0,595,842,fill=1,stroke=0)
text(c,'RELAY / EMERGENCY CONNECT',60,774,10,True,BLUE)
text(c,'Design statement',58,717,33,True)
text(c,'DPS Modern Indian School, Al Wakrah',60,684,12,color=MUTED)
c.setStrokeColor(BLUE);c.setLineWidth(2);c.line(60,658,122,658)
parts=statement.replace('The prototype demonstrates','\nThe prototype demonstrates').replace('Large controls','\nLarge controls')
yy=para(c,parts,60,617,475,16,25,INK)
text(c,str(len(statement.split()))+' words',60,yy-15,10,color=MUTED)
c.setStrokeColor(LINE);c.setLineWidth(.6);c.line(60,151,535,151)
text(c,'Atif Al Azad',60,119,17,True);text(c,'XI-D | 10673 | Rose House',60,95,12,color=MUTED)
text(c,'atif10ala.github.io/relay-emergency-connect/',60,47,10,color=BLUE);c.linkURL(URL,(58,37,450,62),relative=0,thickness=0)
c.showPage();c.save();statement_pdf=st.getvalue();assert len(PdfReader(io.BytesIO(statement_pdf)).pages)==1
def post(name,data):urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:4176/'+name,data=data,method='POST')).read()
post('RELAY-submission.pdf',interface);post('RELAY-statement.pdf',statement_pdf)
z=io.BytesIO()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as package:
 for path in sorted((OUT/'screens').glob('*.png')):package.writestr(path.name,path.read_bytes())
 package.writestr('README.txt','Ten screens and states from the interactive RELAY prototype. Phone frames use only rounded edges and the Dynamic Island. Requests and notifications are simulated.')
post('RELAY-screen-exports.zip',z.getvalue())
print(json.dumps({'interface_pages':5,'interface_bytes':len(interface),'statement_pages':1,'statement_bytes':len(statement_pdf),'statement_words':len(statement.split()),'font':REG}))
