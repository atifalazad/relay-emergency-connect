
export const ESCALATION_MS=30000;
export function escalateRequest(state,now,offline,force=false){
 if(!['waiting','escalation-failed'].includes(state.status))return state;
 if(state.status==='escalation-failed'&&!force)return state;
 if(!force&&(!state.sentAt||now-state.sentAt<ESCALATION_MS))return state;
 return {...state,status:offline?'escalation-failed':'escalated',escalatedAt:offline?null:now};
}
export function locationLabel(state,places){
 const place=places.find(p=>p.id===state.place);
 if(state.locationChoice==='unknown')return 'Location unknown';
 const hasFloor=Number.isInteger(state.floor);
 const floor=hasFloor?(state.floor===0?'Ground floor':'Floor '+state.floor):'Floor not specified';
 const block=state.block||(state.place==='west'?'A':state.place==='central'?'C':null);
 if(state.locationChoice==='indoor'&&block)return block+' Block · '+floor;
 if(place)return place.name+(place.kind==='building'&&hasFloor?' · '+floor:'');
 if(state.locationChoice==='indoor')return floor+' · Block not specified';
 if(state.locationChoice==='outside')return 'Outside · Area not specified';
 return 'Location not chosen';
}
