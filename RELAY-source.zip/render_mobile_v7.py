import subprocess,urllib.request,json
from pathlib import Path
from pypdf import PdfReader
r=Path(__file__).resolve().parent
out=r.parent.parent/'outputs'/'mobile-submission'
exe='C:/Users/Anas Al Azad/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin/pdftoppm.exe'
for filename,prefix in [('RELAY-submission.pdf','interface'),('RELAY-statement.pdf','statement')]:
 reader=PdfReader(out/filename)
 for n in range(1,len(reader.pages)+1):
  p=subprocess.run([exe,'-f',str(n),'-l',str(n),'-singlefile','-scale-to','1400','-png',str(out/filename)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
  assert p.stdout.startswith(b'\x89PNG'),p.stderr
  urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:4176/'+prefix+'-'+str(n)+'.png',data=p.stdout,method='POST')).read()
 print(json.dumps({'pdf':filename,'pages':len(reader.pages),'text_chars':[len(p.extract_text()) for p in reader.pages]}))
