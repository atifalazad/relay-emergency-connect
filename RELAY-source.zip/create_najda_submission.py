import io,json,urllib.request,zipfile
from pathlib import Path
from PIL import Image
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from pypdf import PdfReader
ROOT=Path(__file__).resolve().parent
OUT=ROOT.parent.parent/'outputs'/'mobile-submission'
REG,BOLD='Helvetica','Helvetica-Bold'
try:
 pdfmetrics.registerFont(TTFont('NajdaSans','C:/Windows/Fonts/segoeui.ttf'))
 pdfmetrics.registerFont(TTFont('NajdaBold','C:/Windows/Fonts/segoeuib.ttf'))
 REG,BOLD='NajdaSans','NajdaBold'
except Exception:pass
INK=HexColor('#152038');MUTED=HexColor('#56657e');BLUE=HexColor('#087c80');PAPER=HexColor('#f7f9fc');LINE=HexColor('#dce3ed')
URL='https://atif10ala.github.io/relay-emergency-connect/'
W,H=842,595
statement=(OUT/'NAJDA-statement.txt').read_text(encoding='utf-8').strip()
assert 100<=len(statement.split())<=150
def text(c,s,x,y,size=12,bold=False,color=INK):
 c.setFillColor(color);c.setFont(BOLD if bold else REG,size);c.drawString(x,y,s)
def para(c,s,x,y,width,size=13,leading=20,color=MUTED):
 for raw in s.split('\n'):
  line=''
  for word in raw.split():
   test=(line+' '+word).strip()
   if line and pdfmetrics.stringWidth(test,REG,size)>width:
    text(c,line,x,y,size,color=color);y-=leading;line=word
   else:line=test
  if line:text(c,line,x,y,size,color=color);y-=leading
  y-=5
 return y
def jpeg(path):
 im=Image.open(path).convert('RGB');out=io.BytesIO();im.save(out,'JPEG',quality=86,optimize=True,subsampling=0);out.seek(0);return ImageReader(out)
def phone(c,stem,x,y=72,w=218):
 s=w/417;h=868*s;inner=393*s;image_h=751*s
 c.setFillColor(HexColor('#e1e6ef'));c.roundRect(x+3,y-3,w,h,62*s,fill=1,stroke=0)
 c.setFillColor(HexColor('#181b22'));c.roundRect(x,y,w,h,62*s,fill=1,stroke=0)
 c.setStrokeColor(HexColor('#68727e'));c.setLineWidth(.7);c.roundRect(x+1.5,y+1.5,w-3,h-3,59*s,fill=0,stroke=1)
 ix=x+12*s;iy=y+12*s
 c.setFillColor(HexColor('#ffffff'));c.roundRect(ix,iy,inner,844*s,50*s,fill=1,stroke=0)
 c.saveState();p=c.beginPath();p.roundRect(ix,iy,inner,844*s,50*s);c.clipPath(p,stroke=0,fill=0)
 c.drawImage(jpeg(OUT/'views'/(stem+'.png')),ix,iy+34*s,inner,image_h)
 c.restoreState()
 sy=iy+785*s
 text(c,'9:41',ix+28*s,sy+23*s,14*s,True)
 c.setFillColor(HexColor('#050608'));c.roundRect(x+w/2-63*s,sy+12*s,126*s,36*s,18*s,fill=1,stroke=0)
 c.setFillColor(HexColor('#32d74b'));c.circle(x+w/2+39*s,sy+30*s,2.8*s,fill=1,stroke=0)
 c.setFillColor(INK)
 for i in range(4):c.roundRect(ix+inner-(78-i*5)*s,sy+23*s,3*s,(3+i*2)*s,1*s,fill=1,stroke=0)
 c.setStrokeColor(INK);c.setLineWidth(1.8*s);c.setLineCap(1)
 wx=ix+inner-47*s;wy=sy+23*s
 for radius in [8,5]:
  p=c.beginPath();p.moveTo(wx-radius*s,wy+radius*.6*s);p.curveTo(wx-radius*.55*s,wy+(radius+2)*s,wx+radius*.55*s,wy+(radius+2)*s,wx+radius*s,wy+radius*.6*s);c.drawPath(p,stroke=1,fill=0)
 c.circle(wx,wy+1.6*s,1.5*s,fill=1,stroke=0)
 bx=ix+inner-31*s;by=sy+21*s
 c.setLineWidth(1*s);c.roundRect(bx,by,23*s,11*s,2.8*s,fill=0,stroke=1)
 c.roundRect(bx+2*s,by+2*s,17*s,7*s,1.5*s,fill=1,stroke=0);c.roundRect(bx+24*s,by+3.5*s,1.5*s,4*s,.7*s,fill=1,stroke=0)
 c.roundRect(x+w/2-65*s,iy+10*s,130*s,5*s,2.5*s,fill=1,stroke=0)
def header(c,page):
 c.setFillColor(PAPER);c.rect(0,0,W,H,fill=1,stroke=0)
 c.drawImage(ImageReader(str(ROOT/'public'/'najda-wordmark.png')),39,552,136,33.25,mask='auto')
 c.setStrokeColor(LINE);c.line(39,538,291,538)
 text(c,'atif10ala.github.io/relay-emergency-connect/',39,21,8.8,color=BLUE)
 c.linkURL(URL,(37,13,295,35),relative=0,thickness=0)
 text(c,str(page).zfill(2)+' / 08',770,21,9,color=MUTED)
def feature(c,label,body,y):
 text(c,label,40,y,12,True,BLUE)
 return para(c,body,40,y-22,235,12,18)-16
pages=[
 ('STUDENT / START','Help in\nfour steps.','Help type, location, review and response each have their own phone screen.',
  [('Help choices up front','Medical, unsafe, fire, lost and Not sure are visible at once. Location is one tap above them.'),('Large, distinct choices','Four large emergency icons and a Not sure option fit together. Medical help is selected to start.')],
  ('01-home','01 / HELP TYPE'),('02-help','02 / LOCATION')),
 ('STUDENT / REVIEW','Know what\nyou send.','Large floor and block choices sit on a dedicated location screen. Check the request before sending.',
  [('Easy to move through','Visible Back and Next controls preserve your choices.'),('No page scrolling','The main phone screens fit the viewport. Actions remain below the content, without covering it.')],
  ('03-location','03 / OPTIONAL DETAIL'),('04-review','04 / REVIEW')),
 ('RESPONSE / ESCALATION','A visible\nnext step.','An unanswered request opens the office follow-up screen after 30 seconds.',
  [('A countdown you can see','Delivery, acknowledgement and adult arrival are separate steps.'),('Follow-up stays actionable','Call the school office, message staff or check whether an adult has reached you.')],
  ('05-status','05 / RESPONSE'),('06-escalation','06 / OFFICE FOLLOW-UP')),
 ('RESPONSE / STILL WAITING','No adult?\nKeep it open.','Neither arrival answer is preselected. A timer never confirms handover.',
  [('No means follow up','The request and location stay active. The duty inbox is marked Student still waiting.'),('Yes needs confirmation','Only an explicit handover confirmation closes the request and clears the location.')],
  ('07-handover','07 / ARRIVAL CHECK'),('08-followup','08 / STILL WAITING')),
 ('CONNECTION / SUPPORT','A way to\nreach someone.','Direct calls and text remain available while the request is open.',
  [('An explicit ping channel','A ping is an in-app inbox notification, not SMS or WhatsApp.'),('A quiet connection','Quick replies and messages can be sent before a teacher acknowledges. No staff positions are tracked.')],
  ('09-contact','09 / CONTACT OPTIONS'),('10-chat','10 / STAFF MESSAGES')),
 ('TEACHER / RESPONSE','The other\nside of help.','The shared inbox shows requests immediately, including students who are still waiting.',
  [('A generic duty role','No personal teacher name or phone number is included.'),('Responsibility, then reply','Acknowledge the request and message the student. Adult arrival remains unconfirmed.')],
  ('11-inbox','11 / DUTY INBOX'),('12-incident','12 / REQUEST DETAILS')),
 ('HANDOVER / COMPLETION','Seen is not\nthe same as safe.','Acknowledgement and handover are deliberately separate.',
  [('Arrival stays pending','A teacher seeing the request does not close it.'),('Close after meeting an adult','The student confirms handover. Only then is the selected location cleared.')],
  ('13-acknowledged','13 / ACKNOWLEDGED'),('14-resolved','14 / HANDOVER COMPLETE')),
 ('RELIABILITY / OPTIONAL DETAIL','Clear about\nwhat is known.','The exterior map is optional. Connection failure stays visible.',
  [('A floor is enough','The campus model is approximate. There are no invented room plans or live positions.'),('Unsent stays unsent','Details remain available for retry. Direct-call options are still accessible.')],
  ('15-map','15 / CAMPUS OVERVIEW'),('16-offline','16 / CONNECTION LOSS'))
]
buf=io.BytesIO();c=canvas.Canvas(buf,pagesize=(W,H),pageCompression=1)
c.setTitle('Najda | Emergency Connect | Mobile interface')
c.setAuthor('Atif Al Azad | XI-D | 10673 | Rose House');c.setSubject('Najda | نجدة - Emergency Connect')
for page,(kicker,title,body,features,left,right) in enumerate(pages,1):
 header(c,page);text(c,kicker,40,513,9,True,BLUE)
 yy=477
 for line in title.split('\n'):text(c,line,39,yy,34,True);yy-=40
 yy=para(c,body,40,yy-9,235,14,22)-17
 for label,detail in features:yy=feature(c,label,detail,yy)
 if page==1:
  text(c,'Atif Al Azad',40,94,14,True);text(c,'XI-D | 10673 | Rose House',40,74,10,color=MUTED)
 if page==8:
  para(c,'Requests, pings and office escalation are simulated. Live delivery and the timing policy require school approval.',40,102,235,9.5,14)
 for entry,x in [(left,330),(right,575)]:
  text(c,entry[1],x+2,550,9,True,BLUE);phone(c,entry[0],x)
 c.showPage()
c.save();interface=buf.getvalue();assert len(PdfReader(io.BytesIO(interface)).pages)==8
# Separate, readable statement file.
st=io.BytesIO();c=canvas.Canvas(st,pagesize=(595,842),pageCompression=1)
c.setTitle('Statement');c.setAuthor('Atif Al Azad | XI-D | 10673 | Rose House')
c.setFillColor(PAPER);c.rect(0,0,595,842,fill=1,stroke=0)

text(c,'Statement',58,717,33,True)

c.setStrokeColor(BLUE);c.setLineWidth(2);c.line(60,658,122,658)
parts=statement.replace('A countdown','\nA countdown').replace('School notebook','\nSchool notebook')
yy=para(c,parts,60,617,475,16,25,INK)

c.setStrokeColor(LINE);c.setLineWidth(.6);c.line(60,151,535,151)
text(c,'Atif Al Azad',60,119,17,True);text(c,'XI-D | 10673 | Rose House',60,95,12,color=MUTED)
text(c,'atif10ala.github.io/relay-emergency-connect/',60,47,10,color=BLUE);c.linkURL(URL,(58,37,450,62),relative=0,thickness=0)
c.showPage();c.save();statement_pdf=st.getvalue();assert len(PdfReader(io.BytesIO(statement_pdf)).pages)==1
def post(name,data):urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:4176/'+name,data=data,method='POST')).read()
post('NAJDA-submission.pdf',interface);post('NAJDA-statement.pdf',statement_pdf)
z=io.BytesIO()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as package:
 for path in sorted((OUT/'screens').glob('*.png')):package.writestr(path.name,path.read_bytes())
 package.writestr('README.txt','Sixteen screens and states from the interactive Najda prototype. PDF phone frames include a Dynamic Island, green indicator, time, signal, Wi-Fi and battery. PNG exports contain the app interface. Requests and notifications are simulated.')
post('NAJDA-screen-exports.zip',z.getvalue())
print(json.dumps({'interface_pages':8,'interface_bytes':len(interface),'statement_pages':1,'statement_bytes':len(statement_pdf),'statement_words':len(statement.split()),'font':REG}))
